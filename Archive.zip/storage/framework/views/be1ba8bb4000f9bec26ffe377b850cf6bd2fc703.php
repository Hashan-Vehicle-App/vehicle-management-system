<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<h2>Request a Vehicle</h2>

<form action="" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Show success message -->
    <?php if(session('success')): ?>

    <div class="mb-4">
        <div class="success"><?php echo e(session('success')); ?></div>
    </div>

    <?php endif; ?>


    <div class="form-group mb-4">
        <label for="vehicleCategory">Select one from Available Vehicles</label>

        <!-- select vehicle category -->
        <select name="vehicleCategory" id="vehicleCategory" class="form-control">
            <?php $__currentLoopData = $vehicleCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- select pickup location -->
    <div class="form-group mb-4">
        <label for="pickupLocation">Pickup Location</label>

        <select name="pickupLocation" id="pickupLocation" class="form-control">
            <option value="-1" disabled selected>Select a pickup location</option>

            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($location->id); ?>"><?php echo e($location->location_name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group mb-4">
        <div class="input-group date">
            <input type="text" class="form-control" value="12-02-2012">
            <div class="input-group-addon">
                <span class="glyphicon glyphicon-th"></span>
            </div>
        </div>
    </div>

    <!-- select deliver location -->
    <div class="form-group mb-4">
        <label for="deliverLocation">Deliver Location</label>

        <select name="deliverLocation" id="deliverLocation" class="form-control">
            <option value="-1" disabled selected>Select a deliver location</option>

            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($location->id); ?>"><?php echo e($location->location_name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clientApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/chandikalakshan/Documents/GitHub/vehicle-management-system/resources/views/client/dashboard.blade.php ENDPATH**/ ?>