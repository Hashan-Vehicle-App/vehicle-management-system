<?php $__env->startSection('title', 'Manage Vehicle Categories'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('createVehicleCategory')); ?>" method="POST" style="max-width: 400px" class="mb-5">
  <?php echo csrf_field(); ?>

  <!-- Show success message -->
  <?php if(session('success')): ?>

  <div class="mb-4">
    <div class="success"><?php echo e(session('success')); ?></div>
  </div>

  <?php endif; ?>

  <!-- Show deleted message -->
  <?php if(session('delete')): ?>

  <div class="mb-4">
    <div class="error"><?php echo e(session('delete')); ?></div>
  </div>

  <?php endif; ?>

  <div class="mb-3">
    <div class="d-flex">
      <div class="w-100" style="flex: 1">
        <input id="vehicleCategoryName" name="vehicleCategoryName" type="text" value="<?php echo e(old('vehicleCategoryName')); ?>" placeholder="Vehicle Category" class="form-control <?php $__errorArgs = ['vehicleCategoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
      </div>

      <div class="ms-3">
        <button type="submit" role="button" class="btn btn-primary">Add Category</button>
      </div>
    </div>

    <!-- Show error message -->
    <?php $__errorArgs = ['vehicleCategoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error mt-4"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

</form>

<!-- Display categories -->
<div class="rounded shadow-sm" style="overflow: hidden;">

  <div class="px-3 pt-3 pb-2" style="background-color: #f5f5f5">
    <h5 class="mb-0">Vehicle Categories</h5>
  </div>

  <div class="bg-white p-4">
    <?php if($vehicleCategories): ?>

    <table class="w-100 table table-bordered mb-0">

      <thead>
        <tr>
          <th>Category</th>
          <th>No. of Vehicles</th>
          <th></th>
          <th></th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $vehicleCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
          <td><?php echo e($category->title); ?></td>
          <td>1</td>
          <td class="text-center">
            <!-- Edit vehicle link -->
            <a href="<?php echo e(route('showEditVehicleCategory', ['id' => $category->id])); ?>" class="btn text-accent cursor-pointer"><i class="fa-solid fa-pen-to-square"></i></a>
          </td>
          <td class="text-center">
            <form action="<?php echo e(route('deleteVehicleCategory', ['id' => $category->id])); ?>" method="POST" onsubmit="return confirm('Are you sure?')">

              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>

              <button type="submit" class="btn text-danger cursor-pointer"><i class="fa-solid fa-trash-can"></i></button>

            </form>
          </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>

    </table>

    <?php else: ?>

    <p>No categories</p>

    <?php endif; ?>
  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/chandikalakshan/Documents/GitHub/vehicle-management-system/resources/views/admin/settings/manageVehicleCategories.blade.php ENDPATH**/ ?>