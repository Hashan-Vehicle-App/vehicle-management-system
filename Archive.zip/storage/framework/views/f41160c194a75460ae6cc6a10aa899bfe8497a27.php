<?php $__env->startSection('title', 'Manage Locations'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('createLocation')); ?>" method="POST" style="max-width: 400px" class="mb-5">
    <?php echo csrf_field(); ?>

    <!-- Show success message -->
    <?php if(session('success')): ?>

    <div class="mb-4">
        <div class="success"><?php echo e(session('success')); ?></div>
    </div>

    <?php endif; ?>

    <!-- Show deleted message -->
    <?php if(session('delete')): ?>

    <div class="mb-4">
        <div class="error"><?php echo e(session('delete')); ?></div>
    </div>

    <?php endif; ?>

    <div class="mb-3">
        <div class="d-flex">
            <div class="w-100" style="flex: 1">
                <input id="locationName" name="locationName" type="text" value="<?php echo e(old('locationName')); ?>" placeholder="Location" class="form-control <?php $__errorArgs = ['locationName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>

            <div class="ms-3">
                <button type="submit" role="button" class="btn btn-primary">Add Location</button>
            </div>
        </div>

        <!-- Show error message -->
        <?php $__errorArgs = ['locationName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error mt-4"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</form>

<!-- Display locations -->
<div class="rounded shadow-sm" style="overflow: hidden;">

    <div class="px-3 pt-3 pb-2" style="background-color: #f5f5f5">
        <h5 class="mb-0">Locations</h5>
    </div>

    <div class="bg-white p-4">
        <?php if($locations): ?>

        <table class="w-100 table table-bordered mb-0">

            <thead>
                <tr>
                    <th>Location Name</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($location->location_name); ?></td>
                    <td class="text-center">
                    </td>
                    <td class="text-center">
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>

        <?php else: ?>

        <p>No locations</p>

        <?php endif; ?>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/chandikalakshan/Documents/GitHub/vehicle-management-system/resources/views/admin/settings/manageLocations.blade.php ENDPATH**/ ?>