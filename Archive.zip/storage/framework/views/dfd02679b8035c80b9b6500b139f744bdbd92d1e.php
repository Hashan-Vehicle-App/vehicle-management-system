<?php $__env->startSection('title', 'Edit Vehicle'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('updateVehicle', ['id' => $vehicle->id])); ?>" method="POST" style="max-width: 400px" class="mb-5">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <!-- Show success message -->
    <?php if(session('success')): ?>

    <div class="mb-4">
        <div class="success"><?php echo e(session('success')); ?></div>
    </div>

    <?php endif; ?>

    <div class="form-group mb-3">
        <label for="vehicleNo">Vehicle No</label>

        <input id="vehicleNo" name="vehicleNo" type="text" value="<?php echo e(old('vehicleNo', $vehicle->vehicle_no)); ?>" class="form-control <?php $__errorArgs = ['vehicleNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

        <?php $__errorArgs = ['vehicleNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group mb-4">
        <label for="vehicleCategory">Category</label>

        <!-- Populate vehicle categories -->
        <select name="vehicleCategory" id="vehicleCategory" class="form-control">

            <?php $__currentLoopData = $vehicleCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($category->id); ?>" <?php echo e(old("vehicleCategory", $vehicle->category_id) == $category->id ? "selected" : ''); ?>><?php echo e($category->title); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <?php $__errorArgs = ['vehicleCategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <button type="submit" role="button" class="btn btn-primary">Edit Vehicle</button>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/chandikalakshan/Documents/GitHub/vehicle-management-system/resources/views/admin/settings/editVehicle.blade.php ENDPATH**/ ?>