<?php $__env->startSection('title', 'Manage Vehicles'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('createVehicle')); ?>" method="POST" style="max-width: 400px" class="mb-5">
  <?php echo csrf_field(); ?>

  <!-- Show success message -->
  <?php if(session('success')): ?>

  <div class="mb-4">
    <div class="success"><?php echo e(session('success')); ?></div>
  </div>

  <?php endif; ?>

  <!-- Show delete message -->
  <?php if(session('delete')): ?>

  <div class="mb-4">
    <div class="error"><?php echo e(session('delete')); ?></div>
  </div>

  <?php endif; ?>

  <div class="form-group mb-3">
    <label for="vehicleNo">Vehicle No</label>

    <input id="vehicleNo" name="vehicleNo" type="text" value="<?php echo e(old('vehicleNo')); ?>" class="form-control <?php $__errorArgs = ['vehicleNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

    <?php $__errorArgs = ['vehicleNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="form-group mb-4">
    <label for="vehicleCategory">Category</label>

    <!-- Populate vehicle categories -->
    <select name="vehicleCategory" id="vehicleCategory" class="form-control">

      <?php $__currentLoopData = $vehicleCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

    <?php $__errorArgs = ['vehicleCategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="error"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div>
    <button type="submit" role="button" class="btn btn-primary">Add Vehicle</button>
  </div>
</form>

<!-- Display vehicles -->
<div class="bg-white rounded shadow-sm" style="overflow: hidden;">

  <div class="px-3 pt-3 pb-2" style="background-color: #f5f5f5">
    <h5>Vehicles</h5>
  </div>

  <div class="bg-white p-4">
    <?php if($vehicles): ?>

    <table class="table table-bordered mb-0">

      <thead>
        <tr>
          <th class="text-left">Vehicle No</th>
          <th class="text-left">Category</th>
          <th class="text-left">Status</th>
          <th></th>
          <th></th>
        </tr>
      </thead>

      <tbody>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr class="border-b border-zinc-400">
          <td><?php echo e($vehicle->vehicle_no); ?></td>
          <td><?php echo e($vehicle->category->title); ?></td>
          <td>
            <div class="badge bg-primary"><?php echo e($vehicle->status); ?></div>
          </td>
          <td class="text-center">
            <!-- Edit vehicle link -->
            <a href="<?php echo e(route('showEditVehicle', ['id' => $vehicle->id])); ?>" class="btn text-accent cursor-pointer"><i class="fa-solid fa-pen-to-square"></i></a>
          </td>
          <td class="text-center">
            <form action="<?php echo e(route('deleteVehicle', ['id' => $vehicle->id])); ?>" method="POST" onsubmit="return confirm('Are you sure?')">

              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>

              <button type="submit" class="btn text-danger cursor-pointer"><i class="fa-solid fa-trash-can"></i></button>

            </form>
          </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>

    </table>

    <?php else: ?>

    <p>No vehicles.</p>

    <?php endif; ?>
  </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/chandikalakshan/Documents/GitHub/vehicle-management-system/resources/views/admin/settings/manageVehicles.blade.php ENDPATH**/ ?>