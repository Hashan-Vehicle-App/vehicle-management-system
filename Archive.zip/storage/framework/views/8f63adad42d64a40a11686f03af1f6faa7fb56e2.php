<?php $__env->startSection('title', 'Edit Vehicle Category'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('updateVehicleCategory', ['id' => $vehicleCategory->id])); ?>" method="POST" style="max-width: 400px" class="mb-5">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <!-- Show success message -->
    <?php if(session('success')): ?>

    <div class="mb-4">
        <div class="success"><?php echo e(session('success')); ?></div>
    </div>

    <?php endif; ?>

    <div class="mb-3">
        <div class="d-flex">
            <div class="w-100" style="flex: 1">
                <input id="vehicleCategoryName" name="vehicleCategoryName" type="text" value="<?php echo e(old('vehicleCategoryName', $vehicleCategory->title)); ?>" placeholder="Vehicle Category" class="form-control <?php $__errorArgs = ['vehicleCategoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>

            <div class="ms-3">
                <button type="submit" role="button" class="btn btn-primary">Edit Category</button>
            </div>
        </div>

        <!-- Show error message -->
        <?php $__errorArgs = ['vehicleCategoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="error mt-4"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/chandikalakshan/Documents/GitHub/vehicle-management-system/resources/views/admin/settings/editVehicleCategory.blade.php ENDPATH**/ ?>